<?php
 
namespace Litmus\Theme\Setup;
 
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
 
class UpgradeData implements UpgradeDataInterface
{
    private $eavSetupFactory;
 
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }
 
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
 
        if ($context->getVersion() && version_compare($context->getVersion(), '1.18.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Category::ENTITY,
                'menu_lable',
                [
                    'type' => 'text',
                    'label' => 'Menu Lable',
                    'input' => 'textarea',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            )
            ->addAttribute(
                \Magento\Catalog\Model\Category::ENTITY,
                'category_title',
                [
                    'type' => 'text',
                    'label' => 'Category Title',
                    'input' => 'textarea',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            );
        }

        if ($context->getVersion() && version_compare($context->getVersion(), '1.19.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Category::ENTITY,
                'menu_landing_title',
                [
                    'type' => 'text',
                    'label' => 'Menu Lable',
                    'input' => 'textarea',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            );
        }

        if ($context->getVersion() && version_compare($context->getVersion(), '1.21.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Product::ENTITY,
                'litmus_kits',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Kits',

               'input' => 'select',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Config\Source\Kits',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]
            );
        }

        if ($context->getVersion() && version_compare($context->getVersion(), '1.22.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY,
                'new_design',
                [
                    'type' => 'text',
                    'label' => 'Is New Design',
                    'input' => 'boolean',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            );
        }

        if ($context->getVersion() && version_compare($context->getVersion(), '1.23.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Product::ENTITY,
                'litmus_additional_keys',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Additional Key Ingredients',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Key',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]
            );
        }
 
        $setup->endSetup();
    }
}