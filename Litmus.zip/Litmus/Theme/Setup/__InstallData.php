<?php
namespace Litmus\Theme\Setup;

 

use Magento\Eav\Setup\EavSetup;

use Magento\Eav\Setup\EavSetupFactory;

use Magento\Framework\Setup\InstallDataInterface;

use Magento\Framework\Setup\ModuleContextInterface;

use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface

{

   private $eavSetupFactory;

 

   public function __construct(EavSetupFactory $eavSetupFactory)

   {

       $this->eavSetupFactory = $eavSetupFactory;

   }

 

   public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)

   {

       $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

       // Product Specification Attribute
       //$eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'litmus_test');
       $eavSetup->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_specification',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Specification',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Specification',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       )
       ->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_certificate',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Certificates',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Certificate',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       )
       ->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_tags',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Tags',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Tag',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       )
       ->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_key_ingredients',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product Key Ingredients',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Key',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       )
       ->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_howto_apply',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product how to apply',

               'input' => 'multiselect',

               'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',

               'class' => '',

               'source' => 'Litmus\Theme\Model\Attribute\Source\Apply',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       )
       ->addAttribute(

           \Magento\Catalog\Model\Product::ENTITY,

           'litmus_list_ingredients',

           [

               'group' => 'General',

               'attribute_set_id' => 'Bag',

               'type' => 'varchar',

               'backend' => '',

               'frontend' => '',

               'label' => 'Product All Ingredients Text',

               'input' => 'textarea',

               'backend' => '',

               'class' => '',

               'source' => '',

               'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,

               'visible' => true,

               'required' => false,

               'user_defined' => true,

               'default' => 0,

               'searchable' => true,

               'filterable' => true,

               'comparable' => true,

               'visible_on_front' => true,

               'sort_order' => 101,

               'option' => [

                   'values' => [],

                ]

           ]

       );

   }

}