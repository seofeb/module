<?php
 
namespace Litmus\Theme\Setup;
 
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
 
class UpgradeData implements UpgradeDataInterface
{
    private $eavSetupFactory;
 
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }
 
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
 
        if ($context->getVersion() && version_compare($context->getVersion(), '1.18.0.0') < 0) {
 
            // PLACEHOLDER: add attribute code goes here
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Category::ENTITY,
                'menu_lable',
                [
                    'type' => 'text',
                    'label' => 'Menu Lable',
                    'input' => 'textarea',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            )
            ->addAttribute(
                \Magento\Catalog\Model\Category::ENTITY,
                'category_title',
                [
                    'type' => 'text',
                    'label' => 'Category Title',
                    'input' => 'textarea',
                    'required' => false,
                    'source' => '',
                    'sort_order' => 4,
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'wysiwyg_enabled' => true,
                    'is_html_allowed_on_front' => true,
                    'group' => 'General Information',
                ]
            );
        }
 
        $setup->endSetup();
    }
}