<?php
namespace Litmus\Theme\Block\Adminhtml\Faqs\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Faqs\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Faqs\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('faqs_form');
        $this->setTitle(__('Faqs Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Faqs $model */
        $model = $this->_coreRegistry->registry('theme_faqs');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('faqs_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Faqs'), 'class' => 'fieldset-wide']
        );
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

        // Layouts - Dropdown
        if (!$model->getId()) {
            $model->setSection('brand philosophy'); // Set Default Status 
        }
        $layouts = $this->_status->toLayoutsArray();
        $fieldset->addField(
            'section',
            'select',
            ['name' => 'section', 'label' => __('Faq Section'), 'title' => __('Faq Section'), 'required' => true, 'values' => $layouts]
        );
        
        $fieldset->addField(
            'ques',
            'text',
            ['name' => 'ques', 'label' => __('Question'), 'title' => __('Question'), 'required' => true]
        );

        $fieldset->addField(
            'ans',
            'text',
            ['name' => 'ans', 'label' => __('Answer'), 'title' => __('Answer'), 'required' => true]
        );

        $fieldset->addField(
            'email',
            'text',
            ['name' => 'email', 'label' => __('Content Email'), 'title' => __('Content Email'), 'required' => true]
        );
 
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Faqstional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}