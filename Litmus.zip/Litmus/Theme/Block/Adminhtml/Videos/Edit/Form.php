<?php
namespace Litmus\Theme\Block\Adminhtml\Videos\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
    protected $_cats;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Videos\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Videos\Status $status,
        \Litmus\Theme\Model\Source\Videos\GetCat $getcat,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        $this->_cats = $getcat;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('videos_form');
        $this->setTitle(__('Videos Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Videos $model */
        $model = $this->_coreRegistry->registry('theme_videos');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('videos_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Home Page Videos Seller Image'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Videos\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

        // Name
            $fieldset->addField(
            'name',
            'text',
            ['name' => 'name', 'label' => __('Name'), 'title' => __('Name'), 'required' => true]
            );

        // Name
            $fieldset->addField(
            'title',
            'text',
            ['name' => 'title', 'label' => __('Video Title'), 'title' => __('Video Title'), 'required' => false]
            );

        // Video Image
            $fieldset->addField(
            'youtube_thumb',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Youtube Thumbnail'),
            'label' => __('Youtube Thumbnail'),
            'name' => 'youtube_thumb',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Videos\Renderer\SlideImage',
            ] );

            // Image Url
            $fieldset->addField(
            'youtube_url',
            'text',
            ['name' => 'youtube_url', 'label' => __('Youtube Url'), 'title' => __('Youtube Url'), 'required' => true]
            );
            
            // Image Content
            $fieldset->addField(
            'content',
            'textarea',
            ['name' => 'content', 'label' => __('Video Content'), 'title' => __('Video Content'), 'required' => true]
            );

            $allCats = $this->_cats->toOptionArray();
            $fieldset->addField(
            'category',
            'select',
            ['name' => 'category', 'label' => __('Select Category'), 'title' => __('Select Category'), 'required' => true, 'values' => $allCats]
            );

            $isMain = $this->_status->isMainArray();
            $fieldset->addField(
                'is_main',
                'select',
                ['name' => 'is_main', 'label' => __('Main video?'), 'title' => __('Main Video?'), 'required' => true, 'values' => $isMain]
            );

            // Youtube Url
            $isMain = $this->_status->isMainArray();
            $fieldset->addField(
            'is_trending',
            'select',
            ['name' => 'is_trending', 'label' => __('Trending Video ?'), 'title' => __('Trending Video ?'), 'required' => true, 'values' => $isMain]
            );

        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Videostional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );
        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}