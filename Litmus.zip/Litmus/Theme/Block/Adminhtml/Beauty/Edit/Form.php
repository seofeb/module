<?php
namespace Litmus\Theme\Block\Adminhtml\Beauty\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Beauty\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Beauty\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('beauty_form');
        $this->setTitle(__('Beauty Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Beauty $model */
        $model = $this->_coreRegistry->registry('theme_beauty');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('beauty_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Home Page Beauty Seller Image'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Beauty\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */


        /* IMAGES */
            
            // Beauty Seller Image Field
            $fieldset->addField(
            'beauty_image',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Beauty Advice Image'),
            'label' => __('Beauty Advice Image'),
            'name' => 'beauty_image',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Beauty\Renderer\SlideImage',
            ] );
            
        /* # IMAGES */
            
            // Image Url
            $fieldset->addField(
            'image_url',
            'text',
            ['name' => 'image_url', 'label' => __('Image Link'), 'title' => __('Image Link'), 'required' => true]
            );

            // Image Title
            $fieldset->addField(
            'image_title',
            'text',
            ['name' => 'image_title', 'label' => __('Image Title'), 'title' => __('Image Title'), 'required' => true]
            );

            // Image Content
            $fieldset->addField(
            'image_content',
            'textarea',
            ['name' => 'image_content', 'label' => __('Image Content'), 'title' => __('Image Content'), 'required' => true]
            );

            // Youtube Url
            $fieldset->addField(
            'youtube_url',
            'text',
            ['name' => 'youtube_url', 'label' => __('Youtube Link'), 'title' => __('Youtube Link'), 'required' => true]
            );

            // Video Image
            $fieldset->addField(
            'video_image',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Youtube Video Image'),
            'label' => __('Youtube Video Image'),
            'name' => 'video_image',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Beauty\Renderer\SlideImage',
            ] );

            // Video Title
            $fieldset->addField(
            'video_title',
            'text',
            ['name' => 'video_title', 'label' => __('Video Title'), 'title' => __('Video Title'), 'required' => true]
            );

            // Video Content
            $fieldset->addField(
            'video_content',
            'textarea',
            ['name' => 'video_content', 'label' => __('Video Content'), 'title' => __('Video Content'), 'required' => true]
            );

        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Beautytional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}