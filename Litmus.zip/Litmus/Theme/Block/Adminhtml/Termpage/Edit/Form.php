<?php
namespace Litmus\Theme\Block\Adminhtml\Termpage\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Termpage\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Termpage\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('termpage_form');
        $this->setTitle(__('Termpage Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Termpage $model */
        $model = $this->_coreRegistry->registry('theme_termpage');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('termpage_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Term Page Data'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Termpage\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

        // Square One Field
        $fieldset->addField(
        'image',
        'image',
        [
        'header' => __('Image 1'),
        'title' => __('Banner Image'),
        'label' => __('Banner Image'),
        'name' => 'image',
        //'note' => 'Banner Size : 530 * 603 px',
        'required' => true,
        'renderer'  => 'Litmus\Theme\Block\Adminhtml\Termpage\Renderer\SlideImage',
        ] );

        $fieldset->addField(
        'page_title',
        'text',
        ['name' => 'page_title', 'label' => __('Page Title'), 'title' => __('Page Title'), 'required' => true]
        );

        $fieldset->addField(
        'page_content',
        'textarea',
        ['name' => 'page_content', 'label' => __('Page Content'), 'title' => __('Page Content'), 'required' => true]
        );

        $fieldset->addField(
        'btn_url',
        'text',
        [
            'name' => 'btn_url', 
            'label' => __('Button Url'), 
            'title' => __('Page Title'), 
            'note' => 'Enter full URL i.e. https://www.ibacosmetics.com/',
            'required' => False
        ]
        );
        

            
 
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Term pages
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        echo '<script>
                require([
                "jquery", 
                "mage/translate", 
                "mage/adminhtml/events", 
                "mage/adminhtml/wysiwyg/tiny_mce/setup"
                ], function(jQuery){
                    wysiwygcompany_description = new wysiwygSetup("termpage_page_content", {
                        "width":"99%",  // defined width of editor
                        "height":"200px", // height of editor
                        "plugins":[{"name":"image"}], // for image
                        "tinymce4":{"toolbar":"formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist | link table charmap","plugins":"advlist autolink lists link charmap media noneditable table contextmenu paste code help table",
                        }
                    });
                    wysiwygcompany_description.setup("exact");
                });
            </script>';
 
        return parent::_prepareForm();
    }
}