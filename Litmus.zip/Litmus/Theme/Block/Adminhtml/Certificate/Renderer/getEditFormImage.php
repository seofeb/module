<?php
/**

This file is for Display thumbnail image on edit page. near by upload image field. 

*/
namespace Litmus\Theme\Block\Adminhtml\Certificate\Renderer;

class getEditFormImage extends \Magento\Framework\Data\Form\Element\Image
{
    protected function _getUrl()
    {   
        $url = 'home_certificate/'.$this->getValue(); // book is image directory
        return $url;
    }
}