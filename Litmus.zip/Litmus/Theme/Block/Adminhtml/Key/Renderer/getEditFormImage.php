<?php
/**

This file is for Display thumbnail image on edit page. near by upload image field. 

*/
namespace Litmus\Theme\Block\Adminhtml\Key\Renderer;

class getEditFormImage extends \Magento\Framework\Data\Form\Element\Image
{
    protected function _getUrl()
    {   
        $url = 'home_key/'.$this->getValue(); // book is image directory
        return $url;
    }
}