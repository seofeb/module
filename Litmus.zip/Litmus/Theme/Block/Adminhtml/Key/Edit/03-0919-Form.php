<?php
namespace Litmus\Theme\Block\Adminhtml\Key\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Key\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Key\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('key_form');
        $this->setTitle(__('Key Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Key $model */
        $model = $this->_coreRegistry->registry('theme_key');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('key_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Product Key Ingredients'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Key\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */


        /* IMAGES */
            
            // Key Seller Image Field
            $fieldset->addField(
            'key_image',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Key Ingredients Image'),
            'label' => __('Key Ingredients Image'),
            'name' => 'key_image',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Key\Renderer\SlideImage',
            ] );

            // background image
            $fieldset->addField(
            'key_bg_image',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Ingredients Background Image'),
            'label' => __('Ingredients Background Image'),
            'name' => 'key_bg_image',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Key\Renderer\SlideImage',
            ] );
            
        /* # IMAGES */
            
            $fieldset->addField(
                'title',
                'text',
                ['name' => 'title', 'label' => __('Title'), 'title' => __('Title'), 'required' => true]
            );
            $fieldset->addField(
                'content',
                'textarea',
                ['name' => 'content', 'label' => __('Content'), 'title' => __('Content'), 'required' => true]
            );

        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Keytional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}