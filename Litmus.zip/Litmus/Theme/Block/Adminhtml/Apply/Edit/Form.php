<?php
namespace Litmus\Theme\Block\Adminhtml\Apply\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Apply\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Apply\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('apply_form');
        $this->setTitle(__('Apply Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Apply $model */
        $model = $this->_coreRegistry->registry('theme_apply');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('apply_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Product How to Apply Section Details'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Apply\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

        $fieldset->addField(
            'name',
            'text',
            ['name' => 'name', 'label' => __('Name'), 'title' => __('Name'), 'required' => true]
        );
        
        $fieldset->addField(
            'content',
            'textarea',
            ['name' => 'content', 'label' => __('Content'), 'title' => __('Content'), 'required' => false]
        );

        /* IMAGES */
            
            // Beauty Seller Image Field
            $fieldset->addField(
            'video_image',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Video Thumbnail'),
            'label' => __('Video Thumbnail'),
            'name' => 'video_image',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => false,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Beauty\Renderer\SlideImage',
            ] );
            
        /* # IMAGES */
        
        $fieldset->addField(
            'video_url',
            'text',
            ['name' => 'video_url', 'label' => __('Youtube Url'), 'title' => __('Youtube Url'), 'required' => false]
        );

        $fieldset->addField(
            'apply_content',
            'textarea',
            ['name' => 'tips_content', 'label' => __('Tips Content'), 'title' => __('Tips Content'), 'required' => true]
        );

        /* IMAGES */
            
            // Beauty Seller Image Field
            $fieldset->addField(
            'image_bg',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Background Image'),
            'label' => __('Background Image'),
            'name' => 'image_bg',
            'note' => 'Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Beauty\Renderer\SlideImage',
            ] );
            
        /* # IMAGES */
            
            
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Applytional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        echo '<script>
                require([
                "jquery", 
                "mage/translate", 
                "mage/adminhtml/events", 
                "mage/adminhtml/wysiwyg/tiny_mce/setup"
                ], function(jQuery){
                    wysiwygcompany_description = new wysiwygSetup("apply_content", {
                        "width":"99%",  // defined width of editor
                        "height":"200px", // height of editor
                        "plugins":[{"name":"image"}], // for image
                        "tinymce4":{"toolbar":"formatselect | bold italic underline | alignleft aligncenter alignright | bullist numlist | link table charmap","plugins":"advlist autolink lists link charmap media noneditable table contextmenu paste code help table",
                        }
                    });
                    wysiwygcompany_description.setup("exact");
                });
            </script>';
 
        return parent::_prepareForm();
    }
}