<?php
namespace Litmus\Theme\Block\Adminhtml\Best\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Best\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Best\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('best_form');
        $this->setTitle(__('Best Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Best $model */
        $model = $this->_coreRegistry->registry('theme_best');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('best_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Home Page Best Seller Image'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Best\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */


        /* IMAGES */
            
            // Best Seller Image Field
            $fieldset->addField(
            'best_seller',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Best Seller Image'),
            'label' => __('Best Seller Image'),
            'name' => 'best_seller',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Best\Renderer\SlideImage',
            ] );
            
        /* # IMAGES */
 
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Besttional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}