<?php
namespace Litmus\Theme\Block\Adminhtml\Promo\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Promo\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Promo\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('promo_form');
        $this->setTitle(__('Promo Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Promo $model */
        $model = $this->_coreRegistry->registry('theme_promo');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('promo_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Home Page Promotional Grid'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Promo\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

            // At home page - Dropdown
            if (!$model->getId()) {
                $model->setLayout(1); // Set Default Status 
            }
            $layouts = $this->_status->atHomeStatus();
            $fieldset->addField(
                'onhome',
                'select',
                ['name' => 'onhome', 'label' => __('Show On Home Page ?'), 'title' => __('At Home?'), 'required' => true, 'values' => $layouts]
            );

        // test fields

            $selectField = $fieldset->addField('imgtype', 'select', array(
                'label' => 'Image Type',
                'name' => 'imgtype',           
                'values' => array(
                    array(
                        'value' => "Vertical",
                        'label' => 'Vertical',
                    ),
                    array(
                        'value' => "Horizontal",
                        'label' => 'Horizontal',
                    ),
                    array(
                        'value' => "Horizontal-Small-Images",
                        'label' => 'Horizontal Small Images',
                    ),
                )
            ));

            /*$hideField = $fieldset->addField('field_to_hide', 'text', ['name' => 'field_name','value'=> 'your_value', 'label' => __('Your label Name')]
            );*/

                

        // test fields ends
            
            // Square One Field
            $fieldset->addField(
            'bannerimage',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Banner Image'),
            'label' => __('Banner Image'),
            'name' => 'bannerimage',
            //'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Promo\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'bannerimage_url',
            'text',
            ['name' => 'bannerimage_url', 'label' => __('Banner Image Link'), 'title' => __('Banner Image Link'), 'required' => true]
            );

            $hideField = $fieldset->addField(
            'bannerimagesecond',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Banner Image Second'),
            'label' => __('Banner Image Second'),
            'name' => 'bannerimagesecond',
            //'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Promo\Renderer\SlideImage',
            ] );

            $hideField2 = $fieldset->addField(
            'bannerimagesecond_url',
            'text',
            ['name' => 'bannerimagesecond_url', 'label' => __('Banner Image Second Link'), 'title' => __('Banner Image Second Link'), 'required' => true]
            );

            //code to dependence field
            $dependence = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Widget\Form\Element\Dependence')
                ->addFieldMap($selectField->getHtmlId(), $selectField->getName())
                ->addFieldMap($hideField->getHtmlId(), $hideField->getName())
                ->addFieldDependence(
                    $hideField->getName(),
                    $selectField->getName(),
                    'Horizontal-Small-Images'
                )
                ->addFieldMap($hideField2->getHtmlId(), $hideField2->getName())
                ->addFieldDependence(
                    $hideField2->getName(),
                    $selectField->getName(),
                    'Horizontal-Small-Images'
                );
            $this->setChild('form_after', $dependence);
 
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Promotional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}