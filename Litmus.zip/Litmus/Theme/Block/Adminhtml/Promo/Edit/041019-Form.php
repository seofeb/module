<?php
namespace Litmus\Theme\Block\Adminhtml\Promo\Edit;
 
use \Magento\Backend\Block\Widget\Form\Generic;
 
class Form extends Generic
{
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_status;
 
    /**
     * @var \Magento\Store\Model\System\Store
     */
    //protected $_department;
 
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Litmus\Theme\Model\Source\Promo\Status $status
     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Litmus\Theme\Model\Source\Promo\Status $status,
        //\Litmus\Theme\Model\Source\Department $department,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        //$this->_department = $department;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('promo_form');
        $this->setTitle(__('Promo Informations'));
    }
 
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Litmus\Theme\Model\Promo $model */
        $model = $this->_coreRegistry->registry('theme_promo');
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
 
        $form->setHtmlIdPrefix('promo_');
 
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Home Page Promotional Grid'), 'class' => 'fieldset-wide']
        );

        /* 
            This will fetch Image path for thumbnail on edit form.
        */

         $fieldset->addType(
        'image',
        '\Litmus\Theme\Block\Adminhtml\Promo\Renderer\getEditFormImage'
        );

        /* 
            # Fetching Image path for thumbnail on edit form.
        */
 
        if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        }

        /* FIELDS */

        // Layouts - Dropdown
        if (!$model->getId()) {
            $model->setLayout('Layout One'); // Set Default Status 
        }
        $layouts = $this->_status->toLayoutsArray();
        $fieldset->addField(
            'layout',
            'select',
            ['name' => 'layout', 'label' => __('LAYOUT TYPE'), 'title' => __('layout'), 'required' => true, 'values' => $layouts]
        );

        /* BANNER IMAGES */
            
            // Square One Field
            $fieldset->addField(
            'squareone',
            'image',
            [
            'header' => __('Image 1'),
            'title' => __('Square One'),
            'label' => __('Square One'),
            'name' => 'squareone',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Promo\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'squareone_url',
            'text',
            ['name' => 'squareone_url', 'label' => __('Squareone Link'), 'title' => __('Squareone Link'), 'required' => true]
            );
         
            // Square Two Field
            $fieldset->addField(
            'squaretwo',
            'image',
            [
            'header' => __('Image 2'),
            'title' => __('Square Two'),
            'label' => __('Square Two'),
            'name' => 'squaretwo',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Slides\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'squaretwo_url',
            'text',
            ['name' => 'squaretwo_url', 'label' => __('SquareTwo Link'), 'title' => __('SquareTwo Link'), 'required' => true]
            );


            // Square Three Field
            $fieldset->addField(
            'squarethree',
            'image',
            [
            'header' => __('Image 3'),
            'title' => __('Square Three'),
            'label' => __('Square Three'),
            'name' => 'squarethree',
            'note' => 'Banner Size : 530 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Slides\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'squarethree_url',
            'text',
            ['name' => 'squarethree_url', 'label' => __('SquareThree Link'), 'title' => __('SquareThree Link'), 'required' => true]
            );

            // Rectangle Field
            $fieldset->addField(
            'rectangle',
            'image',
            [
            'header' => __('Image 4'),
            'title' => __('Rectangle'),
            'label' => __('Rectangle'),
            'name' => 'rectangle',
            'note' => 'Banner Size : 1090 * 603 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Slides\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'rectangle_url',
            'text',
            ['name' => 'rectangle_url', 'label' => __('Rectangle Link'), 'title' => __('Rectangle Link'), 'required' => true]
            );

            // Rectone Field
            $fieldset->addField(
            'rectone',
            'image',
            [
            'header' => __('Image 5'),
            'title' => __('Rectone'),
            'label' => __('Rectone'),
            'name' => 'rectone',
            'note' => 'Banner Size : 530 * 280 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Slides\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'rectone_url',
            'text',
            ['name' => 'rectone_url', 'label' => __('Rectone Link'), 'title' => __('Rectone Link'), 'required' => true]
            );

            // Recttwo Field
            $fieldset->addField(
            'recttwo',
            'image',
            [
            'header' => __('Image 6'),
            'title' => __('Recttwo'),
            'label' => __('Recttwo'),
            'name' => 'recttwo',
            'note' => 'Banner Size : 530 * 290 px',
            'required' => true,
            'renderer'  => 'Litmus\Theme\Block\Adminhtml\Slides\Renderer\SlideImage',
            ] );

            $fieldset->addField(
            'recttwo_url',
            'text',
            ['name' => 'recttwo_url', 'label' => __('Recttwo Link'), 'title' => __('Recttwo Link'), 'required' => true]
            );
            
        /* #BANNER IMAGES */
 
        // Status - Dropdown
        if (!$model->getId()) {
            $model->setStatus('1'); // Enable status when adding a Promotional Banners
        }
        $statuses = $this->_status->toOptionArray();
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'), 'required' => true, 'values' => $statuses]
        );

        /* # FIELDS */ 
 
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
 
        return parent::_prepareForm();
    }
}