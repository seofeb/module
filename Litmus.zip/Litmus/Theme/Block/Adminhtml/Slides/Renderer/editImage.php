<?php
/**

This file is for Display thumbnail image on edit page. near by upload image field. 

*/
namespace Litmus\Theme\Block\Adminhtml\Slides\Renderer;

class editImage extends \Magento\Framework\Data\Form\Element\Image
{
    protected function _getUrl()
    {   
        $url = 'home_slides/'.$this->getValue(); // book is image directory
        return $url;
    }
}