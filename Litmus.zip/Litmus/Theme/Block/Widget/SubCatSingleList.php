<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;

class SubCatSingleList extends Template implements BlockInterface {

		protected $_template = "widget/subCatSingleList.phtml";
		protected $categoryRepository;
		//new
		protected $_categoryFactory;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Magento\Catalog\Model\CategoryRepository $categoryRepository,

	    	//new
	    	\Magento\Catalog\Model\CategoryFactory $categoryFactory,

	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    
			    $this->objectManager = $objectManager;
			    $this->categoryRepository = $categoryRepository;

			    //new
			    $this->_categoryFactory = $categoryFactory;
			    parent::__construct($context, $data);
		}

		
		public function getDescendants($categoryId, $levels = 2)
		{
		    $parent_category_id = $categoryId;
			$category = $this->categoryRepository->get($parent_category_id);
			//$subcategories = $categoryObj->getChildrenCategories();
			$collection = $category->getCollection()
	                ->addIsActiveFilter()
	                ->addOrderField('name')
	                ->addIdFilter($category->getChildren());


			return $collection;
		}

		public function yourFunction($current_cat_id)
		{
		    //$current_cat_id = $this->_registry->registry('current_category')->getId();
		    $categoryData = $this->_categoryFactory->create()->load($current_cat_id);
		    $getContent = $categoryData->getData('menu_lable'); //is_home_page = your attribute code
		    return $getContent;
		}
}