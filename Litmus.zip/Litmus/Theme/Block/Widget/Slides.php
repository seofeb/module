<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Slides extends Template implements BlockInterface {

		protected $_template = "widget/slides.phtml";
		protected $_filesystem;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\SlidesFactory $slidesFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_slidesFactory = $slidesFactory;
			    $this->objectManager = $objectManager;
			    parent::__construct($context, $data);
		}

		public function sliderCollection(){

		    $slidcollection = $this->_slidesFactory->create()->getCollection();
		    //return $slidcollection->setOrder('entity_id','DESC');
		    return $slidcollection->setOrder('slide_order','ASC');

		}
		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_slides/';
        }

}