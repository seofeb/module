<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Beauty extends Template implements BlockInterface {

		protected $_template = "widget/beautyAdvice.phtml";
		protected $_filesystem;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\BeautyFactory $beautyFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_beautyFactory = $beautyFactory;
			    $this->objectManager = $objectManager;
			    parent::__construct($context, $data);
		}

		public function homeBeautyCollection(){

		    return $this->_beautyFactory->create()->getCollection();

		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_beauty/';
        }

}