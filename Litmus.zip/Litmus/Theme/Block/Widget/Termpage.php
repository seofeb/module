<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Termpage extends Template implements BlockInterface {

		protected $_template = "widget/termpage.phtml";
		protected $_filesystem;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\TermpageFactory $termpageFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_termpageFactory = $termpageFactory;
			    $this->objectManager = $objectManager;
			    parent::__construct($context, $data);
		}

		public function termpageCollection(){

		    $termpagecollection = $this->_termpageFactory->create()->getCollection();
		    return $termpagecollection->setOrder('entity_id','DESC');

		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_termpageBanners/';
        }

}