<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;

 
class Weuse extends Template implements BlockInterface {

		protected $_template = "widget/Weuse.phtml";
		protected $_filesystem;
		protected $collectionFactory;
		protected $request;
		protected $productVisibility;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\KeyFactory $keyFactory,
	    	\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory,
	    	\Magento\Framework\App\Request\Http $request,
	    	ObjectManagerInterface $objectManager,
	    	\Magento\Catalog\Model\Product\Visibility $productVisibility,
		    array $data = array()
		) {
			    $this->_keyFactory = $keyFactory;
			    $this->objectManager = $objectManager;
			    $this->collectionFactory = $collectionFactory;
			    $this->request = $request;
			    $this->productVisibility = $productVisibility;
			    parent::__construct($context, $data);
		}

		public function getparam(){
			return $this->request->getParam('catId');
		}

		public function keyCollection(){

		    $keyColletion = $this->_keyFactory->create()->getCollection();
		    return $keyColletion->setOrder('entity_id','DESC');
		}

		// fetches all the products by ingrediant id
		public function prodCollect()
		{
			$param = $this->getparam();
			// litmus_key_ingredients
		    $productCollection = $this->collectionFactory->create();
		 
		    // return $productCollection->addAttributeToSelect('*')->addAttributeToFilter('litmus_key_ingredients',array('in' => array($param)));

		     $collection =  $productCollection->addAttributeToSelect('*')->addFieldToFilter('litmus_key_ingredients',array('finset' => array($param)));

		    // check this
		    return $collection->setVisibility($this->productVisibility->getVisibleInSiteIds());

		    //addAttributeToFilter('author_name', array('eq' => 45));
		    

		    /*foreach ($productCollection as $product){
		         echo 'Name  =  '.$product->getName().'<br>';
		    } */ 

		}

		// fetches all the products by additional ingrediant id
		public function prodAddCollect()
		{
			$param = $this->getparam();
			// litmus_key_ingredients
		    $productCollection = $this->collectionFactory->create();
		 
		    // return $productCollection->addAttributeToSelect('*')->addAttributeToFilter('litmus_key_ingredients',array('in' => array($param)));

		     $collection =  $productCollection->addAttributeToSelect('*')->addFieldToFilter('litmus_additional_keys',array('finset' => array($param)));

		    // check this
		    return $collection->setVisibility($this->productVisibility->getVisibleInSiteIds());

		    //addAttributeToFilter('author_name', array('eq' => 45));
		    

		    /*foreach ($productCollection as $product){
		         echo 'Name  =  '.$product->getName().'<br>';
		    } */ 

		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_key/';
        }

}