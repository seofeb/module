<?php
namespace Litmus\Theme\Block\Widget;
use Magento\Framework\View\Element\Template;
 
class Gettermpages extends Template implements \Magento\Framework\Option\ArrayInterface
{

	public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\TermpageFactory $termpageFactory,
		    array $data = array()
	) {
		    $this->_termpageFactory = $termpageFactory;
		    parent::__construct($context, $data);
	}

    public function toOptionArray()
    {
        /*return [
        ['value' => 'mal', 'label' => __('Male')],
        ['value' => 'female', 'label' => __('Female')]];*/

        $termpagecollection = $this->_termpageFactory->create()->getCollection();
		$data = $termpagecollection->setOrder('entity_id','DESC');
		foreach ($data as $pages) {
			$id = $pages['entity_id'];
			$title = $pages['page_title'];
			$allPages[] = ['value' => $id, 'label' => $title];
		}

		return $allPages;
    }
}