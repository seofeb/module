<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Faqs extends Template implements BlockInterface {

		protected $_template = "widget/faqs.phtml";
		protected $_filesystem;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\FaqsFactory $faqsFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_faqsFactory = $faqsFactory;
			    $this->objectManager = $objectManager;
			    parent::__construct($context, $data);
		}

		public function faqsCollection(){

		    return $this->_faqsFactory->create()->getCollection();

		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_faqs/';
        }

}