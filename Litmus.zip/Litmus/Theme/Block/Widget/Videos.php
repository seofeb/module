<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Videos extends Template implements BlockInterface {

		protected $_template = "widget/videos.phtml";
		protected $_filesystem;
		protected $_categoryFactory;

		protected $request;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\VideosFactory $videosFactory,
	    	\Magento\Catalog\Model\CategoryFactory $categoryFactory,
	    	ObjectManagerInterface $objectManager,
	    	\Magento\Framework\App\Request\Http $request,
		    array $data = array()
		) {
			    $this->_videosFactory = $videosFactory;
			    $this->_categoryFactory = $categoryFactory;
			    $this->objectManager = $objectManager;
			    $this->request = $request;
			    parent::__construct($context, $data);
		}

		public function videosCollection(){

		    return $this->_videosFactory->create()->getCollection();

		}

		public function getparam(){
			return $this->request->getParam('catId');
		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_videos/';
        }

        public function getCat($current_cat_id)
		{
		    
		    $categoryData = $this->_categoryFactory->create()->load($current_cat_id);
		    $getContent = $categoryData->getName();
		    return $getContent;
		}

}