<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\ObjectManagerInterface;
 
class Promo extends Template implements BlockInterface {

		protected $_template = "widget/promo.phtml";
		protected $_filesystem;

		 public function __construct(
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\PromoFactory $promoFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_promoFactory = $promoFactory;
			    $this->objectManager = $objectManager;
			    parent::__construct($context, $data);
		}

		public function homePromoCollection(){

		    return $this->_promoFactory->create()->getCollection();

		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_promoBanners/';
        }

}