<?php 
namespace Litmus\Theme\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
// for image Path
use Magento\Framework\ObjectManagerInterface;
 
class Best extends Template implements BlockInterface {

		protected $_template = "widget/best.phtml";
		protected $_filesystem;
		//for category
		protected $categoryFactory;
		//for product image
		protected $_storeManagerInterface;
		//for product star rating
		protected $_reviewFactory;
		

		 public function __construct(
		 	//for category
		 	\Magento\Catalog\Model\CategoryFactory $categoryFactory,
		 	// for product in stock check
		 	\Magento\CatalogInventory\Helper\Stock $stockFilter,
		 	//for product image
		 	\Magento\Store\Model\StoreManagerInterface $storeManagerInterface,
		 	//for product star rating
		 	\Magento\Review\Model\ReviewFactory $reviewFactory,
		 
	    	\Magento\Framework\View\Element\Template\Context $context,
	    	\Litmus\Theme\Model\BestFactory $bestFactory,
	    	ObjectManagerInterface $objectManager,
		    array $data = array()
		) {
			    $this->_bestFactory = $bestFactory;
			    $this->objectManager = $objectManager;
			    //for category
			    $this->categoryFactory = $categoryFactory;
			    // for product in stock check
			    $this->_stockFilter = $stockFilter; 
			    //for product image
			    $this->_storeManagerInterface = $storeManagerInterface;
			    //for product star rating
			    $this->_reviewFactory = $reviewFactory;
			    
			    parent::__construct($context, $data);
		}

		public function bestSellerImage(){
		    return $this->_bestFactory->create()->getCollection();
		}

		public function getMediaUrl(){

            $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

            return $media_dir.'home_bestSeller/';
        }

        
		public function getCatProdById($catId)
		{		
			$category = $this->categoryFactory->create()->load($catId);
		    //$category->getProductCollection()->addAttributeToSelect('*'); 
		    $collection = $category->getProductCollection();
		    $collection->addAttributeToSelect('*');
		    $collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
	        //only filter in stock product
	        $this->_stockFilter->addInStockFilterToCollection($collection);
			return $collection;
		}
		//for product image
		public function getProdImage($imgUrl){
		   $store = $this->_storeManagerInterface->getStore();
		   $storeMedia = $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $imgUrl;
		   return $storeMedia;
		}

		//for product star rating
		public function getRatingSummary($product)
		{
		    $this->_reviewFactory->create()->getEntitySummary($product,$this->_storeManager->getStore()->getId());
		    $ratingSummary = $product->getRatingSummary()->getRatingSummary();

		    return $ratingSummary;
		}

		public  function getCategoryInfo($catId)
	    {
	        return $this->categoryFactory->create()->load($catId);
			
	    }
}