<?php 
namespace Litmus\Theme\Block\Product;
use Magento\Framework\ObjectManagerInterface;
use Litmus\Theme\Model\ApplyFactory;
use Magento\Framework\Data\Collection;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class HowToApply extends Template 
//class SpecificationData extends \Magento\Catalog\Block\Product\View\Attributes
{

	protected $_registry;

  public function __construct(Context $context,
          ObjectManagerInterface $objectManager,
          
          ApplyFactory $ApplyFactory,
          \Magento\Framework\Registry $registry,
          array $data = [])
      {
          $this->objectManager = $objectManager;
          $this->_ApplyFactory = $ApplyFactory;
          $this->_registry = $registry;
          parent::__construct($context, $data);
      }

  public function getCurrentProduct()
  {        
      return $this->_registry->registry('current_product');
  }

  public function getMediaUrl($folder){

      $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
          ->getStore()
          ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

      return $media_dir.$folder.'/';
  }

  public function applyData($attrId)
  {
    return $this->_ApplyFactory->create()->load($attrId)->getData();
  }

}