<?php 
namespace Litmus\Theme\Block\Product;
use Magento\Framework\ObjectManagerInterface;
use Litmus\Theme\Model\KeyFactory;
use Magento\Framework\Data\Collection;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class KeyIngredientsData extends Template 
//class SpecificationData extends \Magento\Catalog\Block\Product\View\Attributes
{

	protected $_registry;

  public function __construct(Context $context,
          ObjectManagerInterface $objectManager,
          KeyFactory $KeyFactory,
          \Magento\Framework\Registry $registry,
          array $data = [])
      {
          $this->objectManager = $objectManager;
          
          $this->_KeyFactory = $KeyFactory;
          $this->_registry = $registry;
          parent::__construct($context, $data);
      }

  public function getCurrentProduct()
  {        
      return $this->_registry->registry('current_product');
  }

  public function getMediaUrl($folder){

      $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
          ->getStore()
          ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

      return $media_dir.$folder.'/';
  }

  public function keyData($attrId)
  {
    $keyCollection = $this->_KeyFactory->create()->load($attrId);
    return $keyCollection->getData();
  }

}