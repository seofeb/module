<?php 
namespace Litmus\Theme\Block\Product;
use Magento\Framework\ObjectManagerInterface;
use Litmus\Theme\Model\SpecificationFactory;
use Litmus\Theme\Model\CertificateFactory;
use Litmus\Theme\Model\TagFactory;
use Litmus\Theme\Model\KeyFactory;
use Litmus\Theme\Model\ApplyFactory;
use Magento\Framework\Data\Collection;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class CustomAttrData extends Template 
//class SpecificationData extends \Magento\Catalog\Block\Product\View\Attributes
{

	protected $_registry;

  public function __construct(Context $context,
          ObjectManagerInterface $objectManager,
          SpecificationFactory $SpecificationFactory,
          CertificateFactory $CertificateFactory,
          TagFactory $TagFactory,
          KeyFactory $KeyFactory,
          ApplyFactory $ApplyFactory,
          \Magento\Framework\Registry $registry,
          array $data = [])
      {
          $this->objectManager = $objectManager;
          $this->_SpecificationFactory = $SpecificationFactory;
          $this->_CertificateFactory = $CertificateFactory;
          $this->_TagFactory = $TagFactory;
          $this->_KeyFactory = $KeyFactory;
          $this->_ApplyFactory = $ApplyFactory;
          $this->_registry = $registry;
          parent::__construct($context, $data);
      }

  public function getCurrentProduct()
  {        
      return $this->_registry->registry('current_product');
  }

  public function getMediaUrl($folder){

      $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
          ->getStore()
          ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

      return $media_dir.$folder.'/';
  }

  public function specifiData($attrId)
  {
    $specificationCollection = $this->_SpecificationFactory->create()->load($attrId);
    return $specificationCollection->getData();
  }

  public function certificateData($attrId)
  {
    $specificationCollection = $this->_CertificateFactory->create()->load($attrId);
    return $specificationCollection->getData();
  }

  public function tagData($attrId)
  {
    $specificationCollection = $this->_TagFactory->create()->load($attrId);
    return $specificationCollection->getData();
  }

  public function keyData($attrId)
  {
    $keyCollection = $this->_KeyFactory->create()->load($attrId);
    return $keyCollection->getData();
  }

  public function applyData($attrId)
  {
    return $this->_ApplyFactory->create()->load($attrId)->getData();
  }

}