<?php

namespace Litmus\Theme\Model\Attribute\Source;

class Key extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource

{
	protected $_layouts;

	public function __construct(\Litmus\Theme\Model\Key $key)
    {
        $this->_key = $key;
    }

	public function getAllOptions()
	{

    if (!$this->_options) {

    	$layoutsCollection = $this->_key->getCollection()
            ->addFieldToSelect('entity_id')
            ->addFieldToSelect('title');
        	
        	$keys[] = ['label' => __('Deselect'), 'value' => 0];
        	
        	foreach ($layoutsCollection as $field) {
            	$keys[] = ['label' => __($field->getTitle()), 'value' => $field->getId()];
            }


	        $this->_options = $keys;
       

    }

    return $this->_options;

 	}

	/*public function getOptionText($value)

    {

      foreach ($this->getAllOptions() as $option) {

          if ($option['value'] == $value) {

              return $option['label'];

          }

      }

      return false;

    }*/

    public function getOptionText($value)
    {
        $isMultiple = false;
        if (strpos($value, ',')) {
            $isMultiple = true;
            $value = explode(',', $value);
        }

        $options = $this->getAllOptions();

        if (!is_array($value)) {
            $value = [$value];
        }
        $optionsText = [];
        foreach ($options as $item) {
            if (in_array($item['value'], $value)) {
                //$optionsText[] = $item['label'];
                $optionsText[] = $item['value'];
            }
        }

        if ($isMultiple) {
            return $optionsText;
        } elseif ($optionsText) {
            return $optionsText[0];
        }

        return false;
    }

}