<?php
namespace Litmus\Theme\Model\Source\Termpage;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Termpage
     */
    protected $_termpage;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Termpage $termpage
     */
    public function __construct(\Litmus\Theme\Model\Termpage $termpage)
    {
        $this->_termpage = $termpage;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_termpage->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

    public function atHomeStatus()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_termpage->getAvailableHome();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}