<?php
namespace Litmus\Theme\Model\Source\Certificate;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Certificate
     */
    protected $_certificate;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Certificate $certificate
     */
    public function __construct(\Litmus\Theme\Model\Certificate $certificate)
    {
        $this->_certificate = $certificate;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_certificate->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}