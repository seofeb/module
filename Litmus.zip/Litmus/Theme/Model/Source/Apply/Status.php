<?php
namespace Litmus\Theme\Model\Source\Apply;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Apply
     */
    protected $_apply;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Apply $apply
     */
    public function __construct(\Litmus\Theme\Model\Apply $apply)
    {
        $this->_apply = $apply;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_apply->getAvailableStatuses();
        foreach ($availableOptions as $apply => $value) {
            $options[] = [
                'label' => $value,
                'value' => $apply,
            ];
        }
        return $options;
    }
}