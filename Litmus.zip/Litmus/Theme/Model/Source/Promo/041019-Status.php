<?php
namespace Litmus\Theme\Model\Source\Promo;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Promo
     */
    protected $_promo;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Promo $promo
     */
    public function __construct(\Litmus\Theme\Model\Promo $promo)
    {
        $this->_promo = $promo;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_promo->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

    public function toLayoutsArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_promo->getAvailableLayouts();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}