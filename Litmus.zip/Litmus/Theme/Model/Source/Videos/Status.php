<?php
namespace Litmus\Theme\Model\Source\Videos;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Videos
     */
    protected $_videos;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Videos $videos
     */
    public function __construct(\Litmus\Theme\Model\Videos $videos)
    {
        $this->_videos = $videos;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_videos->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
    public function isMainArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_videos->getRadioOptions();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}