<?php
namespace Litmus\Theme\Model\Source\Specification;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Specification
     */
    protected $_specification;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Specification $specification
     */
    public function __construct(\Litmus\Theme\Model\Specification $specification)
    {
        $this->_specification = $specification;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_specification->getAvailableStatuses();
        foreach ($availableOptions as $specification => $value) {
            $options[] = [
                'label' => $value,
                'value' => $specification,
            ];
        }
        return $options;
    }
}