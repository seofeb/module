<?php
namespace Litmus\Theme\Model\Source\Best;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Best
     */
    protected $_best;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Best $best
     */
    public function __construct(\Litmus\Theme\Model\Best $best)
    {
        $this->_best = $best;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_best->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}