<?php
namespace Litmus\Theme\Model\Source\Faqs;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Faqs
     */
    protected $_faqs;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Faqs $faqs
     */
    public function __construct(\Litmus\Theme\Model\Faqs $faqs)
    {
        $this->_faqs = $faqs;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_faqs->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

    public function toLayoutsArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_faqs->getAvailableLayouts();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}