<?php
namespace Litmus\Theme\Model\Source\Avoid;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Avoid
     */
    protected $_avoid;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Avoid $avoid
     */
    public function __construct(\Litmus\Theme\Model\Avoid $avoid)
    {
        $this->_avoid = $avoid;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_avoid->getAvailableStatuses();
        foreach ($availableOptions as $avoid => $value) {
            $options[] = [
                'label' => $value,
                'value' => $avoid,
            ];
        }
        return $options;
    }
}