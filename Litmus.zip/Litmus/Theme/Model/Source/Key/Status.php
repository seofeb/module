<?php
namespace Litmus\Theme\Model\Source\Key;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Key
     */
    protected $_key;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Key $key
     */
    public function __construct(\Litmus\Theme\Model\Key $key)
    {
        $this->_key = $key;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_key->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}