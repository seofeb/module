<?php
namespace Litmus\Theme\Model\Source\Beauty;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Beauty
     */
    protected $_beauty;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Beauty $beauty
     */
    public function __construct(\Litmus\Theme\Model\Beauty $beauty)
    {
        $this->_beauty = $beauty;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_beauty->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}