<?php
namespace Litmus\Theme\Model\Source\Tag;
 
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @var \Litmus\Theme\Model\Tag
     */
    protected $_tag;
 
    /**
     * Constructor
     *
     * @param \Litmus\Theme\Model\Tag $tag
     */
    public function __construct(\Litmus\Theme\Model\Tag $tag)
    {
        $this->_tag = $tag;
    }
 
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_tag->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}