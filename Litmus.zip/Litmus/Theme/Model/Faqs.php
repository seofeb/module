<?php
namespace Litmus\Theme\Model;
 
use \Magento\Framework\Model\AbstractModel;
 
class Faqs extends AbstractModel
{
    const FAQS_ID = 'entity_id'; // We define the id fieldname
    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'litmus'; // parent value is 'core_abstract'
 
    /**
     * Name of the event object
     *
     * @var string
     */
    protected $_eventObject = 'faqss'; // parent value is 'object'
 
    /**
     * Name of object id field
     *
     * @var string
     */
    protected $_idFieldName = self::FAQS_ID; // parent value is 'id'
 
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\ResourceModel\Faqs');
    }
    
    public function getEnableStatus() {
    return 1;
	}
 
	public function getDisableStatus() {
    return 0;
	}
    public function getAvailableStatuses() {
        return [$this->getDisableStatus() => __('Disabled'), $this->getEnableStatus() => __('Enabled')];
    }

// For Layouts Dropdown
    public function getLayoutOne() {
    return "brand philosophy";
    }
 
    public function getLayoutTwo() {
    return "product safety & effectiveness";
    }
    public function getLayoutThree() {
    return "shopping & shipping";
    }
    public function getAvailableLayouts() {
        return [$this->getLayoutOne() => __('brand philosophy'), $this->getLayoutTwo() => __('product safety & effectiveness'), $this->getLayoutThree() => __('shopping & shipping')];
    }
 
}