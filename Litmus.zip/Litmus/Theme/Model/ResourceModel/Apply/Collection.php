<?php
namespace Litmus\Theme\Model\ResourceModel\Apply;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Apply" class
    protected $_idFieldName = \Litmus\Theme\Model\Apply::BEST_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Apply', 'Litmus\Theme\Model\ResourceModel\Apply');
    }
}