<?php
namespace Litmus\Theme\Model\ResourceModel\Tag;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Tag" class
    protected $_idFieldName = \Litmus\Theme\Model\Tag::BEST_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Tag', 'Litmus\Theme\Model\ResourceModel\Tag');
    }
}