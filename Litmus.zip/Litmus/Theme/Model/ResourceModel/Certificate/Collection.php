<?php
namespace Litmus\Theme\Model\ResourceModel\Certificate;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Certificate" class
    protected $_idFieldName = \Litmus\Theme\Model\Certificate::BEST_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Certificate', 'Litmus\Theme\Model\ResourceModel\Certificate');
    }
}