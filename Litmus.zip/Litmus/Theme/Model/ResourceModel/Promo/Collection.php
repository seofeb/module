<?php
namespace Litmus\Theme\Model\ResourceModel\Promo;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Promo" class
    protected $_idFieldName = \Litmus\Theme\Model\Promo::PROMO_ID;
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Promo', 'Litmus\Theme\Model\ResourceModel\Promo');
    }
 
}