<?php
namespace Litmus\Theme\Model\ResourceModel\Best;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Best" class
    protected $_idFieldName = \Litmus\Theme\Model\Best::BEST_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Best', 'Litmus\Theme\Model\ResourceModel\Best');
    }
}