<?php
namespace Litmus\Theme\Model\ResourceModel\Faqs;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Faqs" class
    protected $_idFieldName = \Litmus\Theme\Model\Faqs::FAQS_ID;
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Faqs', 'Litmus\Theme\Model\ResourceModel\Faqs');
    }
 
}