<?php
namespace Litmus\Theme\Model\ResourceModel\Slides;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Slides" class
    protected $_idFieldName = \Litmus\Theme\Model\Slides::SLIDER_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Slides', 'Litmus\Theme\Model\ResourceModel\Slides');
    }
 
}