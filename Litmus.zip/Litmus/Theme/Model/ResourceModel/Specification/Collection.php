<?php
namespace Litmus\Theme\Model\ResourceModel\Specification;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    // We've define this within "\Litmus\Theme\Model\Specification" class
    protected $_idFieldName = \Litmus\Theme\Model\Specification::BEST_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Litmus\Theme\Model\Specification', 'Litmus\Theme\Model\ResourceModel\Specification');
    }
}