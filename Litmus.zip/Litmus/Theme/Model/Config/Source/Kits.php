<?php

namespace Litmus\Theme\Model\Config\Source;

class Kits extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
    * Get all options
    *
    * @return array
    */
    public function getAllOptions()
    {
        $this->_options = [
                ['label' => __('No Button'), 'value'=>'0'],
                ['label' => __('Black Button'), 'value'=>'1'],
                ['label' => __('White Button'), 'value'=>'2']
            ];

    return $this->_options;

    }

}