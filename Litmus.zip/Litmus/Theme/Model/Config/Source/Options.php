<?php 
namespace Litmus\Theme\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

class Options extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{ 

    /**
     * @var \Vendor\Module\Model\SpecificationFactory
     */
    private $SpecificationFactory;

    /**
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
    public function __construct(\Litmus\Theme\Model\SpecificationFactory $SpecificationFactory)
    {
        $this->SpecificationFactory = $SpecificationFactory;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        $customCollection = $this->SpecificationFactory->create()->getCollection();
        
        $this->_options = [['label'=>'Please select', 'value'=>'']];
        foreach($customCollection as $custom)
        {
            $this->_options[] = ['label'=> $custom->getTitle(), 'value' => $custom->getId()];
        }
        return $this->_options;
    }

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }
}