<?php
namespace Litmus\Theme\Controller\Adminhtml\Termpage;
 
use Magento\Backend\App\Action;
 
class Delete extends Action
{
    protected $_model;
 
    /**
     * @param Action\Context $context
     * @param \Litmus\Theme\Model\Termpage $model
     */
    public function __construct(
        \Litmus\Theme\Model\ResourceModel\Termpage\CollectionFactory $fetchDataFactory,
        \Litmus\Theme\Model\Termpage $model,
        Action\Context $context,
        // for Remove image
        \Magento\Framework\Filesystem\Driver\File $file
    ) {
        parent::__construct($context);
        $this->_model = $model;
        $this->fetchDataFactory = $fetchDataFactory;
        // for Remove image
        $this->_file = $file;
    }
 
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::termpage_delete');
    }
 
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $id = $this->getRequest()->getParam('id');


        // To fetch whole data.
        //$this->fetchDataFactory->create();

        // To collection filter by Id
        $datas = $this->fetchDataFactory->create()->addFieldToFilter('entity_id', $id); 

        // get all image(s) fields

        foreach($datas->getData()[0] as $keys => $images){
            if(
                $keys == 'image'): 

                $imagesAry[] = $images; endif;
        }

        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
            $mediaRootDir = $mediaDirectory->getAbsolutePath().'home_termpageBanners/';

        foreach($imagesAry as $fields){
            $fileName = $fields;
            /* for Remove image */

            if(!empty($fields))
            if ($this->_file->isExists($mediaRootDir . $fileName))  {
               $result[] =  $this->_file->deleteFile($mediaRootDir . $fileName);
            }
            /* for Remove image */
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->_model;
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccess(__('Item Deleted'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('Item does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}