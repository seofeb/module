<?php
namespace Litmus\Theme\Controller\Adminhtml\Best;
 
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
 
class Index extends Action
{

    // It’s define the permission we define on the ACL
    const ADMIN_RESOURCE = 'Litmus_Theme::best';
 
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
 
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 
    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        //die("working...");
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();

        // It’s define in menu file.
        $resultPage->setActiveMenu('Litmus_Theme::best');
        /* $resultPage->addBreadcrumb(__('Jobs'), __('Jobs')); */
        
        // First parameter is element label, second is the title. A third parameters is available and it’s the link of the element.
        $resultPage->addBreadcrumb(__('Theme'), __('Best Seller Image'));
        // Page Title
        $resultPage->getConfig()->getTitle()->prepend(__('Best Seller Image'));
 
        return $resultPage;
    }
}