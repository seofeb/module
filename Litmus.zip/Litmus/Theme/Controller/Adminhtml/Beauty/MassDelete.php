<?php
namespace Litmus\Theme\Controller\Adminhtml\Beauty;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Litmus\Theme\Model\ResourceModel\Beauty\CollectionFactory;
 
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var Filter
     */
    protected $filter;
 
    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;
    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(Context $context, Filter $filter, CollectionFactory $collectionFactory, \Magento\Framework\Filesystem\Driver\File $file)
    {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
        $this->_file = $file;
    }
    /**
     * Execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $collectionSize = $collection->getSize();

        
        /* for Remove image */
        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $mediaRootDir = $mediaDirectory->getAbsolutePath().'home_beauty/';
        /* #for Remove image */

        foreach ($collection as $item) {

            foreach($item->getData() as $keys => $images){
                if(
                $keys == 'beauty_image' || $keys == 'video_image'): 
                    
                    $fileName = $images;
                    if ($this->_file->isExists($mediaRootDir . $fileName))  {
                        $result[] = $this->_file->deleteFile($mediaRootDir . $fileName);
                    }
                    
                endif;
            }

            $item->delete(); 
        }

        /*foreach ($collection as $item) {

            $fileName = $item->getImage();
            if ($this->_file->isExists($mediaRootDir . $fileName))  {
                $result[] = $this->_file->deleteFile($mediaRootDir . $fileName);
            }
            //$item->delete();
        }*/
        $this->messageManager->addSuccess(__('A total of %1 Beauty Sections(s) have been deleted.', $collectionSize));
 
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }
}