<?php
namespace Litmus\Theme\Controller\Adminhtml\Slides;
 
use Magento\Backend\App\Action;
 
class Delete extends Action
{
    protected $_model;
 
    /**
     * @param Action\Context $context
     * @param \Litmus\Theme\Model\Slides $model
     */
    public function __construct(
        \Litmus\Theme\Model\ResourceModel\Slides\CollectionFactory $fetchDataFactory,
        Action\Context $context,
        \Litmus\Theme\Model\Slides $model,
        // for Remove image
        \Magento\Framework\Filesystem\Driver\File $file
    ) {
        parent::__construct($context);
        $this->_model = $model;
        $this->fetchDataFactory = $fetchDataFactory;
        // for Remove image
        $this->_file = $file;
    }
 
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::slides_delete');
    }
 
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $id = $this->getRequest()->getParam('id');


        // To fetch whole F**king data..
        //$this->fetchDataFactory->create();

        // To collection filter by Id
        $datas = $this->fetchDataFactory->create()->addFieldToFilter('entity_id', $id); 
        
        $dataArray = $datas->getData();

        $fileName = $dataArray[0]['image'];

        /* for Remove image */
        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $mediaRootDir = $mediaDirectory->getAbsolutePath().'home_slides/';
        
        try{
            if ($this->_file->isExists($mediaRootDir . $fileName))  {
               $result =  $this->_file->deleteFile($mediaRootDir . $fileName);
               if(!$result == 1){
                    throw new \Exception('Image not found or can not delete.');
               }
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        /* for Remove image */

        //echo $dataArray->image;

        /*foreach ($datas as $item) {
            
            echo $item->getImage();
            print_r($item->getData());
        }*/


        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->_model;
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccess(__('Slide deleted'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('Slide does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}