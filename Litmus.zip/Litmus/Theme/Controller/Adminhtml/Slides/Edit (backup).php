<?php
namespace Litmus\Theme\Controller\Adminhtml\Slides;
 
use Magento\Backend\App\Action;
 
class Edit extends Action
{
    
    protected $_coreRegistry = null;
 
    protected $_resultPageFactory;
 
    protected $_model;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
        \Litmus\Theme\Model\Slides $model
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        $this->_model = $model;
        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::slides_save');
    }

    protected function _initAction()
    {
        // load layout, set active menu and breadcrumbs
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Litmus_Theme::slides')
            ->addBreadcrumb(__('Slides'), __('Slides2'))
            ->addBreadcrumb(__('Slides3'), __('Slides4'));
        return $resultPage;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->_model;
 
        // If you have got an id, it's edition
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This slide not exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
 
                return $resultRedirect->setPath('*/*/');
            }
        }
 
        $data = $this->_getSession()->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
        
        $this->_coreRegistry->register('theme_slides', $model);
 
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit Slide') : __('New Slide2'),
            $id ? __('Edit Slide3') : __('New Slide4')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Slides'));
        $resultPage->getConfig()->getTitle()
            ->prepend($model->getId() ? $model->getName() : __('New Slide'));
 
        return $resultPage;
    }

    protected function _getUrl()
    {
        $url = false;
        if ($this->getValue()) {
            $url = $this->_imageModel
                    ->getBaseUrlMedia() . 'home_slides/' . $this->getValue();
        }
        return $url;
    }
}