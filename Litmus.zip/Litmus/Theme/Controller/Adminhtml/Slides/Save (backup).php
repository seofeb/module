<?php
namespace Litmus\Theme\Controller\Adminhtml\Slides;
 
use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends Action
{
    /**
     * @var \Litmus\Theme\Model\Slides
     */
    protected $_model;
    protected $_fileUploaderFactory;
 
    /**
     * @param Action\Context $context
     * @param \Litmus\Theme\Model\Slides $model
     */
    public function __construct(
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        Action\Context $context,
        \Litmus\Theme\Model\Slides $model
    ) {
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
        $this->_model = $model;
    }
 
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::slides_save');
    }
 
    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            $model = $this->_model;

            $id = $this->getRequest()->getParam('id');
            $editMode = false;
            if ($id) {
                $editMode = true;
                $model->load($id);
                //$model->setCreatedAt(date('Y-m-d H:i:s'));
            }

            if (isset($_FILES['image']) && !empty($_FILES['image']['name']) ) {

                try{

                    $uploadErr = true;

                    $result = $this->fileUpload('image','home_slides');

                    // If file upload success
                    if($result['error']==0) : $data['image'] = $result['file']; $uploadErr = false; endif;       
                
                } catch (\Magento\Framework\Exception\LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\RuntimeException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\Exception $e) {
                    unset($data['image']);
                    $this->messageManager->addError($e->getMessage());
                }
                // this Fires only when image upload with new and edit mode
                if(isset($uploadErr) && $uploadErr == true ) :
                    $this->_getSession()->setFormData($data);
                    return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
                endif;
            
            }   else {
            
                    if (isset($data['image']) && isset($data['image']['value'])) {
                        
                        if (isset($data['image']['delete'])) {
                            
                            $data['image'] = '';
                        } elseif (isset($data['image']['value'])) {
                            
                            //from edit page without image
                            $data['image'] = $data['image']['value'];
                        } 
                    }
                    else
                    {
                        try{
                            if( $editMode == false && empty($data['image']) )
                            {
                                throw new \Exception('Please select the image.');
                            }
                        } catch (\Exception $e) {
                            $this->messageManager->addError($e->getMessage());
                        }
                        // this fires only when new form image not upload
                        if($editMode == false){
                            $this->_getSession()->setFormData($data);
                            return $resultRedirect->setPath('*/*/edit', ['entity_id' => $this->getRequest()->getParam('id')]);
                        }
                    }
                }

            $model->setData($data);

            try {
                    $model->save();
                    $this->messageManager->addSuccess(__('The Slide has been saved.'));
                    $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                    }
                    return $resultRedirect->setPath('*/*/');
                } catch (\Magento\Framework\Exception\LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\RuntimeException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\Exception $e) {
                    $this->messageManager->addException($e, __('Something went wrong while saving the Slide.'));
                    $this->messageManager->addError($e->getMessage());
                }
                
                unset($data['image']);
                $this->_getSession()->setFormData($data);
                return $resultRedirect->setPath('*/*/edit', ['entity_id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }


    public function fileUpload($field,$folder){

        $uploader = $this->_objectManager->create(
            'Magento\MediaStorage\Model\File\Uploader',
            ['fileId' => $field]
        );

        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
    
        $imageAdapter = $this->_objectManager->get('Magento\Framework\Image\AdapterFactory')->create();
        
        $uploader->setAllowRenameFiles(true);
        
        $uploader->setFilesDispersion(false);
        
        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
            ->getDirectoryRead(DirectoryList::MEDIA);

        $result = $uploader->save($mediaDirectory->getAbsolutePath($folder));
        return $result;
    }




    /*public function getslideupload($fieldName,$folderName)
    {
   
        // unique name for image
        $uniq_name = date("DMdYG_i").time().uniqid();
        // get image from post
        $file = $_FILES[$fieldName]['name'];
        // get image extention
        $ext = pathinfo($file, PATHINFO_EXTENSION);

        //_fileUploaderFactory: Is an object of \Magento\MediaStorage\Model\File\UploaderFactory , which handles all the uploading process.
        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'image']);
        
        // Set Allowed Extensions 
        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
        
        // If true and if it finds the same name while saving file within folder it will change the file name by _1...
        $uploader->setAllowRenameFiles(false);
         
        // setFilesDispersion():  If you set it to “false” then your file uploaded to the same path, and if you set it to “true” then it first creates two folders with first two letters of image’s name, and then upload your image inside that folder.
        $uploader->setFilesDispersion(false);

        // Path to media directory in pub folder
        $path = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(DirectoryList::MEDIA)
         
        ->getAbsolutePath($folderName);

        // combine unique name and extension before saving into directory
        $img_name = "$uniq_name.$ext";
        // save(): Is used to upload and save file at the path which you passed inside it. If you want to save the image with custom name, then you need to pass your file name as a second parameter.
        $uploader->save($path,$img_name);
        
        return $img_name;
        
    }*/
}