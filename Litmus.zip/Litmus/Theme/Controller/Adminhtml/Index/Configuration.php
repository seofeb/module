<?php
namespace Litmus\Theme\Controller\Adminhtml\Index;
 
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
 
class Configuration extends Action
{
	protected $resultPageFactory;

	public function __construct(
		Context $context,
		PageFactory $resultPageFactory

	){
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
    {
    	$resultPage = $this->resultPageFactory->create();
    	$this->getRequest()->setParam('section','tipandtrick');
    	$resultPage->setActiveMenu('Litmus_Theme::Configuration');
    	$resultPage->getConfig()->getTitle()->prepend(__('Just a config'));
    	return $resultPage;
    }

    /*// It’s define the permission we define on the ACL
    const ADMIN_RESOURCE = 'Litmus_Theme::slides';
 
    
    protected $resultPageFactory;
 
    
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 
    
    public function execute()
    {
        
        
        $resultPage = $this->resultPageFactory->create();

        // It’s define in menu file.
        $resultPage->setActiveMenu('Litmus_Theme::slides');
        
        
        // First parameter is element label, second is the title. A third parameters is available and it’s the link of the element.
        $resultPage->addBreadcrumb(__('Theme'), __('Sliders'));
        // Page Title
        $resultPage->getConfig()->getTitle()->prepend(__('Home Slider'));
 
        return $resultPage;


    }*/
}