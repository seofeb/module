<?php
namespace Litmus\Theme\Controller\Adminhtml\Avoid;
 
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;
 
class Index extends Action
{

    // It’s define the permission we define on the ACL
    const ADMIN_RESOURCE = 'Litmus_Theme::avoid';
 
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
 
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 
    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        //die("working...");
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();

        // It’s define in menu file.
        $resultPage->setActiveMenu('Litmus_Theme::avoid');
        /* $resultPage->addBreadcrumb(__('Jobs'), __('Jobs')); */
        
        // First parameter is element label, second is the title. A third parameters is available and it’s the link of the element.
        $resultPage->addBreadcrumb(__('Theme'), __('Iba Avoid Ingredients'));
        // Page Title
        $resultPage->getConfig()->getTitle()->prepend(__('Iba Avoid Ingredients'));
 
        return $resultPage;
    }
}