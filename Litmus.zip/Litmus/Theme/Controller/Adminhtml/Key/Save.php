<?php
namespace Litmus\Theme\Controller\Adminhtml\Key;
 
use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends Action
{
    protected $_model;
    protected $_fileUploaderFactory;

    public function __construct(
        Action\Context $context,
        \Litmus\Theme\Model\Key $model,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        // For fetch old image name from table
        \Litmus\Theme\Model\ResourceModel\Key\CollectionFactory $fetchDataFactory,
        // for Remove image
        \Magento\Framework\Filesystem\Driver\File $file
    ) {
        parent::__construct($context);
        $this->_model = $model;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        // For fetch old image name from table
        $this->fetchDataFactory = $fetchDataFactory;
        // for Remove image
        $this->_file = $file;
    }
 
    
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::key_save');
    }
 
    public function execute()
    {
        
        $data = $this->getRequest()->getPostValue();
        

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            $model = $this->_model;

            $id = $this->getRequest()->getParam('id');

            if(isset($data['entity_id'])): $editMode = true; else: $editMode = false; endif;
            
            if ($id) {
                $editMode = true;
                $model->load($id);
            }
                $finalData = array();
                /* #query check */
                
                $allFields = array('key_image','key_bg_image','listing_image');
    
                foreach($allFields as $imgField){
                    if (isset($_FILES[$imgField]) && !empty($_FILES[$imgField]['name']) ) {
            
                        try{

                            $uploadErr = true;
                            // Field & Folder
                            $result = $this->fileUpload($imgField,'home_key');

                            if($result['error']==0) : 
                                $data[$imgField] = $result['file']; 
                                $uploadErr = false;

                                // Remove Old Image
                                if($editMode){
                                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
                                    $mediaRootDir = $mediaDirectory->getAbsolutePath().'home_key/';    
                                    // To collection filter by Id
                                    $datas = $this->fetchDataFactory->create()->addFieldToFilter('entity_id', $data['entity_id']);
                                    $fileName = $datas->getData()[0][$imgField];
                                    if ($this->_file->isExists($mediaRootDir . $fileName))  {
                                       $result[] =  $this->_file->deleteFile($mediaRootDir . $fileName);
                                    }else{}
                                }else{}
                                // # Remove Old Image

                            else:
                                $uploadErr = true;
                            endif;    

                        } catch (\Magento\Framework\Exception\LocalizedException $e) {
                            $this->messageManager->addError($e->getMessage());
                        } catch (\RuntimeException $e) {
                            $this->messageManager->addError($e->getMessage());
                        } catch (\Exception $e) {
                            unset($data[$imgField]);
                            $this->messageManager->addError($e->getMessage());
                        }
                        
                        if(isset($uploadErr) && $uploadErr == true ) :
                            $sesData = $this->array_flatten($data);
                            unset($data[$imgField]);
                            if($editMode){
                                //$this->_getSession()->setFormData($sesData);
                                $this->messageManager->addException($e, __('Reupload '.strtoupper($imgField)));
                                return $resultRedirect->setPath('*/*/edit', ['id' => $data['entity_id']]); 
                            }else{
                                $this->_getSession()->setFormData($sesData);
                                $this->messageManager->addException($e, __('Reupload '.strtoupper($imgField)));
                                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
                            }
                            
                        endif;

                    }   
                    else {

                            if (isset($data[$imgField]) && isset($data[$imgField]['value'])) {
                                
                                if (isset($data[$imgField]['delete'])) {
                                    $data[$imgField] = '';
                                } elseif (isset($data[$imgField]['value'])) {
                                    $data[$imgField] = $data[$imgField]['value'];
                                } 
                            }
                            else
                            {
                                try{
                                    if( $editMode == false && empty($data[$imgField]) ) : 
                                        throw new \Exception(strtoupper($imgField).' is Required !');
                                    endif;
                                } catch (\Exception $e) {
                                    $this->messageManager->addError($e->getMessage());
                                }

                                if($editMode == false) :
                                    $this->_getSession()->setFormData($data);
                                    return $resultRedirect->setPath('*/*/edit', ['entity_id' => $this->getRequest()->getParam('id')]);
                                endif;
                            }
                        } // end else
                } // end foreach
                

            
            try {
                    $model->setData($data);
                    $model->save();
                    $this->messageManager->addSuccess(__('The Key Ingredient has been saved.'));
                    $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                    }
                    return $resultRedirect->setPath('*/*/');
                } catch (\Magento\Framework\Exception\LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\RuntimeException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\Exception $e) {
                    $this->messageManager->addException($e, __('Something went wrong while saving the Ingredient.'));
                    $this->messageManager->addError($e->getMessage());
                }
                
                unset($data['image']);
                $this->_getSession()->setFormData($data);
                return $resultRedirect->setPath('*/*/edit', ['entity_id' => $this->getRequest()->getParam('id')]);
               
        }
        return $resultRedirect->setPath('*/*/');
    }


    public function fileUpload($field,$folder){

        $uploader = $this->_objectManager->create(
            'Magento\MediaStorage\Model\File\Uploader',
            ['fileId' => $field]
        );

        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
    
        $imageAdapter = $this->_objectManager->get('Magento\Framework\Image\AdapterFactory')->create();
        
        $uploader->setAllowRenameFiles(true);
        
        $uploader->setFilesDispersion(false);
        
        $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
            ->getDirectoryRead(DirectoryList::MEDIA);

        $result = $uploader->save($mediaDirectory->getAbsolutePath($folder));
        return $result;
    }

    public function array_flatten($array) { 

      if (!is_array($array)) { 
        return FALSE; 
      } 
      $result = array(); 
      foreach ($array as $key => $value) { 
        if (is_array($value)) { 
          $result = array_merge($result, $this->array_flatten($value)); 
        } 
        else { 
          $result[$key] = $value; 
        } 
      } 
      return $result; 
    } // end function

} // end class