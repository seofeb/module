<?php
namespace Litmus\Theme\Controller\Adminhtml\Tag;
 
use Magento\Backend\App\Action;
 
class Delete extends Action
{
    protected $_model;
 
    /**
     * @param Action\Context $context
     * @param \Litmus\Theme\Model\Tag $model
     */
    public function __construct(
        \Litmus\Theme\Model\ResourceModel\Tag\CollectionFactory $fetchDataFactory,
        \Litmus\Theme\Model\Tag $model,
        Action\Context $context
    ) {
        parent::__construct($context);
        $this->_model = $model;
        $this->fetchDataFactory = $fetchDataFactory;
        
    }
 
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::tag_delete');
    }
 
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $id = $this->getRequest()->getParam('id');

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->_model;
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccess(__('Tag Deleted'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('Image does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}