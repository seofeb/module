<?php
namespace Litmus\Theme\Controller\Adminhtml\Tag;
 
use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends Action
{
    protected $_model;
    protected $_fileUploaderFactory;

    public function __construct(
        Action\Context $context,
        \Litmus\Theme\Model\Tag $model,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        // For fetch old image name from table
        \Litmus\Theme\Model\ResourceModel\Tag\CollectionFactory $fetchDataFactory,
        // for Remove image
        \Magento\Framework\Filesystem\Driver\File $file
    ) {
        parent::__construct($context);
        $this->_model = $model;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        // For fetch old image name from table
        $this->fetchDataFactory = $fetchDataFactory;
        // for Remove image
        $this->_file = $file;
    }
 
    
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Litmus_Theme::tag_save');
    }
 
    public function execute()
    {
        
        $data = $this->getRequest()->getPostValue();
        

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            $model = $this->_model;

            $id = $this->getRequest()->getParam('id');

            if(isset($data['entity_id'])): $editMode = true; else: $editMode = false; endif;
            
            if ($id) {
                $editMode = true;
                $model->load($id);
            }
        
            try {
                    $model->setData($data);
                    $model->save();
                    $this->messageManager->addSuccess(__('The Tag has been saved.'));
                    $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                    }
                    return $resultRedirect->setPath('*/*/');
                } catch (\Magento\Framework\Exception\LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\RuntimeException $e) {
                    $this->messageManager->addError($e->getMessage());
                } catch (\Exception $e) {
                    $this->messageManager->addException($e, __('Something went wrong while saving the Tag.'));
                    $this->messageManager->addError($e->getMessage());
                }
                
                unset($data['image']);
                $this->_getSession()->setFormData($data);
                return $resultRedirect->setPath('*/*/edit', ['entity_id' => $this->getRequest()->getParam('id')]);
               
        }
        return $resultRedirect->setPath('*/*/');
    }

} // end class