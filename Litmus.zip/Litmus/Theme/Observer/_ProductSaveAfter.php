<?php

namespace Litmus\Theme\Observer;

use Magento\Framework\Event\ObserverInterface;

class ProductSaveAfter implements ObserverInterface
{    
    protected $request;
    protected $_options;

    public function __construct( 
        \Magento\Framework\App\Request\Http $request,
        \Magento\Catalog\model\Product\Option $options
    ) 
    { 
        $this->request = $request;
        $this->_options = $options;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        echo "<pre>";
        /*
            $_product = $observer->getProduct();  // you will get product object
            $_sku=$_product->getMagenest(); // for sku
        */

        $requestId = $this->request->getParam('id');
    
        $options = $this->request->getParam('litmus');

        print_r($options); die;

        $specificationStr['specification'] = implode(",",$specificationParam['specification']);
        
        $this->request->setParam('litmus', $specificationStr);
        $model = $this->_CustomProductsFactory->create();



        $model->addData($data);

        $model->save();
        //print_r($this->request->getParam('litmus'));

    }   
}